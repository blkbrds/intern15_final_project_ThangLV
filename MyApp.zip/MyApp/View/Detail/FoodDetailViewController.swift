//
//  FoodDetailViewController.swift
//  MyApp
//
//  Created by Chinh Le on 2/23/20.
//  Copyright © 2020 Asian Tech Co., Ltd. All rights reserved.
//

import UIKit

class FoodDetailViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        title = "FOOD DETAIL"
    }
}
