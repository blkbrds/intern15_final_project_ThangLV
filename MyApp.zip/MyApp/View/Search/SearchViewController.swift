//
//  SearchViewController.swift
//  MyApp
//
//  Created by PCI0008 on 2/17/20.
//  Copyright © 2020 Asian Tech Co., Ltd. All rights reserved.
//

import UIKit

final class SearchViewController: ViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        title = "SEARCH"
    }
}
