//
//  TabBarController.swift
//  MyApp
//
//  Created by Chinh Le on 2/17/20.
//  Copyright © 2020 Asian Tech Co., Ltd. All rights reserved.
//

import Foundation
import UIKit

@available(iOS 11.0, *)
class TabBarController: UITabBarController {
    
    override func viewDidLoad() {
        super.viewDidLoad()
        setupUI()
    }
    
    private func setupUI() {
        let homeViewController = HomeViewController()
        homeViewController.tabBarItem = UITabBarItem(title: "Home", image: UIImage(named: ""), tag: 0)
        let homeNavigationController = NavigationController(rootViewController: homeViewController)
        
        let searchViewController = SearchViewController()
        searchViewController.tabBarItem = UITabBarItem(title: "Search", image: UIImage(named: ""), tag: 1)
        let searchNavigationController = NavigationController(rootViewController: searchViewController)
        
        let favoriteViewController = FavoriteViewController()
        favoriteViewController.tabBarItem = UITabBarItem(title: "Search", image: UIImage(named: ""), tag: 1)
        let favoriteNavigationController = NavigationController(rootViewController: favoriteViewController)
        
        viewControllers = [homeNavigationController, searchNavigationController, favoriteViewController]
    }
}
