//
//  FoodListViewController.swift
//  MyApp
//
//  Created by PCI0008 on 2/20/20.
//  Copyright © 2020 Asian Tech Co., Ltd. All rights reserved.
//

import UIKit

class FoodListViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        title = "FOOD LIST"
    }
}
