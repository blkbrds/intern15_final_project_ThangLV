//
//  Food.swift
//  MyApp
//
//  Created by Chinh Le on 2/22/20.
//  Copyright © 2020 Asian Tech Co., Ltd. All rights reserved.
//

import Foundation
import UIKit

final class Food {
    var image: UIImage?
    var name: String
    var imageUrl: String
    
    init(json: JSONObject) {
        name = json["strMeal"] as? String ?? ""
        imageUrl = json["strMealThumb"] as? String ?? ""
    }
}
