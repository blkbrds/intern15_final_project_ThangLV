//
//  FavoriteTableViewCell.swift
//  MyApp
//
//  Created by Chinh Le on 3/4/20.
//  Copyright © 2020 Asian Tech Co., Ltd. All rights reserved.
//

import UIKit

protocol FavoriteTableViewCellDelegate: class {
    func tableViewCell(tableViewCell: FavoriteTableViewCell, needsPerform action: FavoriteTableViewCell.Action)
}

class FavoriteTableViewCell: UITableViewCell {
    
    enum Action {
        case deleteFood(id: String)
    }

    @IBOutlet weak var foodImageView: UIImageView!
    @IBOutlet weak var foodNameLabel: UILabel!
    @IBOutlet weak var categoryNameLabel: UILabel!
    @IBOutlet weak var countryNameLabel: UILabel!
    @IBOutlet weak var favoriteButton: UIButton!
    @IBOutlet weak var deleteButton: UIButton!
    
    
    var viewModel = FavoriteTableCellViewModel() {
        didSet {
            updateView()
        }
    }
    
    weak var delegate: FavoriteTableViewCellDelegate?
    
    private func updateView() {
        foodNameLabel.text = viewModel.foodName
        categoryNameLabel.text = viewModel.categoryName
        countryNameLabel.text = viewModel.countryName
    }
    
    @IBAction func deleteButtonTouchUpInside(_ sender: Any) {
        
    }
}
