//
//  FavoriteViewController.swift
//  MyApp
//
//  Created by PCI0008 on 2/17/20.
//  Copyright © 2020 Asian Tech Co., Ltd. All rights reserved.
//

import UIKit

final class FavoriteViewController: ViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        title = "FAVORITE"
    }
}
