//
//  FoodDetailViewController.swift
//  MyApp
//
//  Created by Chinh Le on 2/23/20.
//  Copyright © 2020 Asian Tech Co., Ltd. All rights reserved.
//

import UIKit

@available(iOS 11.0, *)
final class FoodDetailViewController: ViewController {
    
    @IBOutlet weak var foodImageView: UIImageView!
    @IBOutlet weak var foodNameLabel: UILabel!
    @IBOutlet weak var categoryNameLabel: UILabel!
    @IBOutlet weak var countryNameLabel: UILabel!
    @IBOutlet weak var infoSegmentedControl: UISegmentedControl!
    @IBOutlet weak var instructionTableView: UITableView!
    @IBOutlet weak var ingredientListLabel: UILabel!
    
    var viewModel: FoodDetailViewModel?
    
    override func viewDidLoad() {
        super.viewDidLoad()
        setupData()
    }
    
    override func setupUI() {
        title = "FOOD DETAIL"
    }
    
    func updateUI() {
        guard let viewModel = viewModel else {
            return
        }
        foodNameLabel.text = viewModel.foodName
        categoryNameLabel.text = viewModel.categoryName
        countryNameLabel.text = viewModel.countryName
    }
    
    override func setupData() {
        guard let viewModel = viewModel else {
            return
        }
        viewModel.getFoods { (done, msg) in
            if done {
                self.updateUI()
            } else {
                print(msg)
            }
        }
    }
}
