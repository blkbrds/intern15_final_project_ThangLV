//
//  FoodDetailViewModel.swift
//  MyApp
//
//  Created by Chinh Le on 2/24/20.
//  Copyright © 2020 Asian Tech Co., Ltd. All rights reserved.
//

import Foundation

@available(iOS 11.0, *)
final class FoodDetailViewModel {
    
    var foods: [Food] = []
    var foodName = ""
    
    init() {}
    
    init(foodName: String) {
        self.foodName = foodName
    }
    
    func getFoods(success: @escaping Success) {
        FoodDetailService.loadFoods(with: foodName) { result in
            switch result {
            case .success(let foods):
                self.foods = foods as? [Food] ?? []
                success(true, "")
            case .failure(let message):
                print(message)
                success(false, message)
            }
        }
    }
    
    var countryName: String {
        guard foods.count > 0 else { return "" }
        return foods[0].countryName
    }
    
    var categoryName: String {
        guard foods.count > 0 else { return "" }
        return foods[0].categoryName
    }
}
