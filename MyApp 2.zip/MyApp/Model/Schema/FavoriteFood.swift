//
//  FavoriteFood.swift
//  MyApp
//
//  Created by Chinh Le on 3/4/20.
//  Copyright © 2020 Asian Tech Co., Ltd. All rights reserved.
//

import Foundation
import RealmSwift

final class FavoriteFood: Object {
    @objc dynamic var foodID: String = ""
    @objc dynamic var foodImage: String = ""
    @objc dynamic var foodName: String = ""
    @objc dynamic var categoryName: String = ""
    @objc dynamic var countryName: String = ""
    
//    func primaryKey() -> String? {
//        return foodName
//    }
    
//    override class func primaryKey() -> String? {
//        return "foodName"
//    }
    
//    init(foodImage: String, foodName: String, categoryName: String, countryName: String) {
//        self.foodImage = foodImage
//        self.foodName = foodName
//        self.categoryName = categoryName
//        self.countryName = countryName
//    }
//
//    required init() {
//        fatalError("init() has not been implemented")
//    }
    
    
}
